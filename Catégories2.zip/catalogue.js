$(function(){
	$('.logo').hover(function(){
		$('#viande').find('div.caption').stop(false,true).fadeIn(1500);
	};
	function(){
		$(this).find('img').stop(false,true).fadeOut(1500);
	})
});

/*FONCTION DE BASE EN JQUERY QUI TE PERMET D'AFFICHER UN MESSAGE CACHE (ca veut dire qu'il est en mode display:none dans ton css)
QUAND ON LE SURVOL

$('TON ID OU TA CLASSE VISé').la méthode()